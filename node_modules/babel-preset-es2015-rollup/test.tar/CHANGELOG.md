# babel-preset-es2015-rollup changelog

## 1.1.0

* Update to use renamed `external-helpers` plugin ([#3](https://github.com/rollup/babel-preset-es2015-rollup/pull/3))
* Use modify-babel-preset ([#4](https://github.com/rollup/babel-preset-es2015-rollup/pull/4))

## 1.0.0

* First release
